% Adds required folders to path
addpath('gwfunctions', 'helperfunctions');